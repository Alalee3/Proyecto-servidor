<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('unidades_curriculares', function (Blueprint $table) {
            $table->string('codigo', 7)->primary();
            $table->unsignedBigInteger('pnf_id');
            $table->string('semestre', 1);
            $table->tinyText('nombre');
            $table->text('descripcion');
            $table->text('proposito');
            $table->string('unidades_credito', 2);
            $table->timestamp('fecha_creacion')->useCurrent();
            $table->enum('estatus', ['1', '2'])->default('1');
            $table->foreign('pnf_id')->references('pnf_id')->on('pnfs');
        });

        schema::create('contenidos', function (Blueprint $table) {
            $table->id('contenido_id');
            $table->string('unidad_codigo', 7);
            $table->text('titulo');
            $table->text('descripcion');
            $table->timestamp('fecha_creacion')->useCurrent();
            $table->enum('estatus', ['1', '2'])->default('1');
            $table->foreign('unidad_codigo')->references('codigo')->on('unidades_curriculares');
        });

        schema::create('indicadores_logros', function (Blueprint $table) {
            $table->id('indicador_id');
            $table->text('descripcion');
            $table->timestamp('fecha_creacion')->useCurrent();
        });

        schema::create('contenido_indicadores', function (Blueprint $table) {
            $table->id('contenido_indicador_id');
            $table->unsignedBigInteger('contenido_id');
            $table->unsignedBigInteger('indicador_id');
            $table->foreign('contenido_id')->references('contenido_id')->on('contenidos');
            $table->foreign('indicador_id')->references('indicador_id')->on('indicadores_logros');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('unidades_curriculares');
        Schema::dropIfExists('contenidos');
        Schema::dropIfExists('indicadores_logros');
        Schema::dropIfExists('contenido_indicadores');
    }
};
