<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('lapso_academico', function (Blueprint $table) {
            $table->id('lapso_id');
            $table->string('nombre', 6);
            $table->dateTime('fecha_inicio');
            $table->dateTime('fecha_fin');
            $table->timestamp('fecha_creacion')->useCurrent();
            $table->enum('estatus', ['1', '2'])->default('1');
        });

        schema::create('secciones', function (Blueprint $table) {
            $table->id('seccion_id');
            $table->string('seccion', 2);
            $table->timestamp('fecha_creacion')->useCurrent();
            $table->unsignedBigInteger('lapso_id');
            $table->enum('estatus', ['1', '2']);
            $table->foreign('lapso_id')->references('lapso_id')->on('lapso_academico');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('lapso_academico');
        Schema::dropIfExists('secciones');
    }
};
