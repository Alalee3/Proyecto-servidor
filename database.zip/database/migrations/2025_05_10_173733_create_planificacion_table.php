<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('planificaciones', function (Blueprint $table) {
            $table->id('planificacion_id');
            $table->unsignedBigInteger('seccion_id');
            $table->timestamp('fecha_creacion')->useCurrent();
            $table->foreign('seccion_id')->references('seccion_id')->on('secciones');
        });

        schema::create('recursos', function (Blueprint $table) {
            $table->id('recurso_id');
            $table->text('nombre');
        });

        schema::create('planificaciones_recursos', function (Blueprint $table) {
            $table->id('planificacion_recurso_id');
            $table->unsignedBigInteger('planificacion_id');
            $table->unsignedBigInteger('recurso_id');
            $table->foreign('planificacion_id')->references('planificacion_id')->on('planificaciones');
            $table->foreign('recurso_id')->references('recurso_id')->on('recursos');
        });

        schema::create('evaluaciones', function (Blueprint $table) {
            $table->id('evaluacion_id');
            $table->text('tecnica');
            $table->text('tipo');
            $table->dateTime('fecha_evaluacion');
        });

        schema::create('planificacion_evaluaciones', function (Blueprint $table) {
            $table->id('planificacion_evaluacion_id');
            $table->unsignedBigInteger('planificacion_id');
            $table->unsignedBigInteger('evaluacion_id');
            $table->foreign('planificacion_id')->references('planificacion_id')->on('planificaciones');
            $table->foreign('evaluacion_id')->references('evaluacion_id')->on('evaluaciones');
        });

        schema::create('estrategias_pedagogicas', function (Blueprint $table) {
            $table->id('estrategia_id');
            $table->text('tecnica');
        });

        schema::create('planificacion_estrategias', function (Blueprint $table) {
            $table->id('planificacion_estrategia_id');
            $table->unsignedBigInteger('planificacion_id');
            $table->unsignedBigInteger('estrategia_id');
            $table->foreign('planificacion_id')->references('planificacion_id')->on('planificaciones');
            $table->foreign('estrategia_id')->references('estrategia_id')->on('estrategias_pedagogicas');
        });

        schema::create('usuarios_planificaciones', function (Blueprint $table) {
            $table->id('usuario_planificacion');
            $table->unsignedBigInteger('id');
            $table->unsignedBigInteger('planificacion_id');
            $table->foreign('id')->references('id')->on('users');
            $table->foreign('planificacion_id')->references('planificacion_id')->on('planificaciones');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('planificaciones');
        Schema::dropIfExists('recursos');
        Schema::dropIfExists('planificaciones_recursos');
        Schema::dropIfExists('evaluaciones');
        Schema::dropIfExists('planificacion_evaluaciones');
        Schema::dropIfExists('estrategias_pedagogicas');
        Schema::dropIfExists('planificacion_estrategias');
        Schema::dropIfExists('usuarios_planificaciones');
    }
};
